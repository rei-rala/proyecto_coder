'Paperless by Rei-rala'  
  

Desafio 3 (entregado 17-04-21):  
Aspectos a incluir en el entregable:  
    
Siguiendo el o los wireframes que creaste en la clase anterior, y en función de las secciones elegidas para tu sitio web, crea los documentos HTML para cada sección del mismo (los cuales luego enlazarás entre sí).
Crea una lista con el menú principal del sitio web, incluyendo los nombres de cada una de las secciones este último. Deberá estar enlazado a los archivos correspondiente, mediante enlaces relativos.
Agrega una tabla para mostrar los beneficios del producto que estés promocionando en tu sitio web. Incluye su nombre, información técnica (lista), características, así como lista de beneficios, comentarios o recomendaciones (lista ordenada).
Incorpora un formulario en la sección que corresponda para contacto. El mismo debe contar con al menos un input, un menú desplegable, un checkbox, un botón para resetear la información introducida y el botón de enviar.  
  
Desafio 4 (entregado 17/04/2021):  

+Consigna: crea un archivo CSS, y linkéalo al HTML entregado en el desafío de la clase anterior, esto es, “Primeros pasos con HTML Asigna color a títulos, párrafos y listas, mediante clases y etiquetas.  
+Aspectos a incluir en el entregable:
Detalle completo acerca de lo que se espera que el estudiante entregue. Se sugiere detallar cada uno de los ítems.
